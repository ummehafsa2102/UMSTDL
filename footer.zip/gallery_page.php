
<?php include 'link.php'; ?>

<?php include 'header.php'; ?>


 <! gallery area  !>

<div class="gallery-area pb-4" style="background-color:#f2f2f2">

<div class="heading"> 
    
         
    <div class="col text-center p-3  " style=""> Our Gallery</div>
   
</div>



<div class="container mt-3">

<div class="row mt-5">

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card "> 
 <img src="images/0-1.jpg" alt="" class="card-img course-img">
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card "> 
 <img src="images/0-2.jpg" alt="" class="card-img course-img">
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card "> 
 <img src="images/0-3.jpg" alt="" class="card-img course-img">
</div>
</div>


</div>



<div class="row mt-5">

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card "> 
 <img src="images/0-4.jpg" alt="" class="card-img course-img">
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card "> 
 <img src="images/0-6.jpg" alt="" class="card-img course-img">
</div>
</div>




</div>







</div>


</div>


    <! End of gallery  area  !>

    
    <?php include 'footer.php'; ?>