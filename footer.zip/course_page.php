
<?php include 'link.php'; ?>

<?php include 'header.php'; ?>


 <! Courses area  !>

<div class="course-area pb-4" style="background-color:#f2f2f2">

<div class="heading"> 
    
         
    <div class="col text-center p-3  " style=""> Our Courses</div>
   
</div>



<div class="container mt-3">

<div class="row mt-5">

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card "> 
<a href="courses/affliateMarketing.php"> <img src="images/a_m.png" alt="" class="card-img course-img"></a>
</div>
<div class="card-body">
    <a href="courses/affliateMarketing.php" class="course-title"> Affliate Marketing</a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12col-4" >
<div class="card"> 
<a href="courses/webDesign.php">  <img src="images/web.jpg" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/webDesign.php" class="course-title">Web Design & Development</a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/cpaDesign.php"> <img src="images/cpa.png" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/cpaDesign.php" class="course-title">CPA Marketing</a>
</div>
</div>


</div>



<div class="row mt-5">

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
 <a href="courses/digitalMarketing.php"><img src="images/d_m.jpg" alt="" class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/digitalMarketing.php" class="course-title">Digital Marketing</a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/youtubeMarketing.php">  <img src="images/2.jpg" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/youtubeMarketing.php" class="course-title">Youtube Marketing</a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/facebookMarketing.php">  <img src="images/f_m.jpg" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/facebookMarketing.php" class="course-title">Facebook Marketing</a>
</div>
</div>


</div>




<div class="row mt-5">

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/basicCom.php">  <img src="images/m_o.jpg" alt="" class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/basicCom.php" class="course-title">Computer Office Application </a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/graphicDesign.php">   <img src="images/g_d.jpg" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/graphicDesign.php" class="course-title">Graphic Design</a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/autocad.php"> <img src="images/a_d.jpg" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
         <a href="courses/autocad.php" class="course-title">Autocad 2D,3D,Max</a>
</div>
</div>


</div>

<div class="row mt-5">

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/hardware.php">  <img src="images/c_h.jpg" alt="" class="card-img course-img"></a>
</div>
<div class="card-body">
      <a href="courses/hardware.php" class="course-title">Computer Hardware </a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/driving.php"> <img src="images/d.jpg" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
      <a href="courses/driving.php" class="course-title">Driving </a>
</div>
</div>

<div class="col-lg-4 col-sm-12 col-md-12" >
<div class="card"> 
<a href="courses/spokenEng.php">  <img src="images/e.jpg" alt=""  class="card-img course-img"></a>
</div>
<div class="card-body">
      <a href="courses/spokenEng.php" class="course-title" >Spoken English</a>
</div>
</div>


</div>

</div>


</div>


    <! End of course  area  !>

    
    <?php include 'footer.php'; ?>