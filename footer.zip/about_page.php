<?php include 'link.php'; ?>
<?php include 'header.php'; ?>



   <div class="container">
       <div class="row">
           <div class="col-lg-5 col-sm-12 col-md-12 mt-5 mb-5 ">
               <img src="images/about-page.jpg" alt="" class="about-img">
           </div>

           <div class="col-lg-7 col-sm-12 col-md-12 mt-5 mb-5">
           <div class="about-text">
               <h1>About<span class="about-heading"> Us</span></h1>
               <div class="border"></div>
             <h3>
             United Multimedia Skill Development Technology Ltd is a professional outsourcing training and freelancing and IT training company in Bangladesh. For developing your skill and making your career path bright  join us as we provide affiliate marketing, Web design and development, CPA marketing, digital marketing, YouTube marketing, Facebook marketing, graphics design, autocade, computer office applications and computer hardware.
             </h3>
             <p>
             United Multimedia Skill Development Technology Ltd is a professional outsourcing training and freelancing and IT training company in Bangladesh. Our institution provide best possible training with professional trainer within affortable cost.
             </p>
             <a href="" class="btn btn-hire col-sm-12  col-md-12">Contact us</a>
           </div>
           </div>

       </div>
   </div>
   <?php include 'footer.php'; ?>