<?php include 'link.php'; ?>

<!--Footer area-->

      <div class="footer-area pb-4 pt-2" style="">

        <div class="container">

          <div class="row">
          
      

          <div class="col-lg-4 col-sm-12 col-md-12 " style="color:#fff">
            <h5 style="font-weight:bold;">About Us</h5>
            <p class="footer-area-text"> United Multimedia Skill Development Technology Ltd is a professional outsourcing training and freelancing and IT training company in Bangladesh. Our institution provide best possible training with professional trainer within affortable cost.</p>
          </div>


          <div class="col-lg-4 col-sm-12 col-md-12 " style="color:#fff">

            <div class="menu text-left" >
            <h5 style="font-weight:bold;">Quick Links</h5>
                <ul class="list-unstyled footer-area-text " >
                  <li ><a class="nav-link footer-area-text  " href="index.php">Home</a></li>
                  <li ><a class="nav-link footer-area-text  " href="about_page.php" >About-Us</a></li>

                  <li ><a class="nav-link footer-area-text " href="contact_page.php" >Contact-Us</a></li> 
                  <li ><a class="nav-link footer-area-text  " href="registration_page.php" >Registration</a></li> 
                </ul>

            </div>

        </div>

        <div class="col-lg-4 col-sm-12 col-md-12 ">
        <h5 style="font-weight:bold;color:#fff;">Get in touch</h5>
            <div class="social-media-footer">
            <a href="https://www.facebook.com/United-multimedia-skill-development-technology-limited-103877671204563/"><i class="fab facebook fa-facebook-f"></i></a>
          <a href="https://twitter.com/umsdtl "><i class="fab twitter fa-twitter"></i></a>
          <a href="https://www.linkedin.com/in/ums-dtl-6945841a2/"><i class="fab linkedin fa-linkedin-in"></i> </a>
            </div>
            <h5 style="font-weight:bold;color:#fff;" class="mt-5 pt-2  col-sm-12 col-md-12 ">Location</h5>
            <p class="footer-area-text ">House # 30 , Block-A , Ward # 53 <br>  Diabari , Turag ,Dhaka</p>
                
        </div>

          </div>
        </div>

      </div>

      <div class="footer-lineend"></div> 
      <div class="footer-rights">
      <p class="text-center p-3 mb-0" style="color:#000; font-weight: 600; font-size: 20px;">Web Amex All rights reserved.</p>
      </div>

      <!--end of footer area-->