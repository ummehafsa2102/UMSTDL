<?php include 'courses_link.php'; ?>
<?php include 'courses_header.php'; ?>  
  
           
        
   
          
     <div class="course-slider vertical-center" >

     <div class="img-text container" >
 
    
        <h1 class="text-center">Computer Office Application</h1>
          <p class="text-center">Learn more about Computer Office Application </p>
        
        <div class="text-center">  <a href=""><i class="fas fa-arrow-down  " style="font-size:70px;color:#4d0099"></i></a>
      </div>

       </div>
       

     </div>


      <div class="information p-5 m-5 ">
        <div class="container">

            <div class="row">

              <div class="col-lg-5 col-sm-12 col-md-12" >
            
                <img src="../images/g_d.jpg" alt="" class="course-img">
            
             </div>

                  <div class="col-lg-7 col-sm-12 col-md-12col-7">

                    <h1>About Course</h1>

                    <div class="border mb-2 "></div>
                  
                        <p style="font-size:18px;line-height:24px;
                        letter-spacing: 1px;">
                         Basic computer application for example ms word PowerPoint excel etc are required in every office work so having knowledge on this is must. We provide this basic training too within couple of days in a easy way. So join our course. 
                        </p>
                
                </div>

            </div>
       </div>    
      </div>

      <div class="border-lineend"></div> 

    <div class="course-join  p-3">

      <div class="text-center">
        <P>For Joining This Course Contact Us!</P> 
        <a href="../contact_page.php" class="btn btn-hire-course  ">Contact</a>
      </div>

   </div> 

    

  </div>
  <?php include 'courses_footer.php'; ?>  
