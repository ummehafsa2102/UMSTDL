
  <?php include 'courses_link.php'; ?>



  <! Header  !>

<div class="header-area" >

  <div class="row">


      <div class="col-lg-1 col-sm-12 col-md-12 ">
        
        </div>


    <div class="col-lg-2 col-sm-12 col-md-12 text-center">
      <h5>01872-167498</h5>
    </div>

   

    
    <div class="col-lg-3 col-sm-12 col-md-12 text-center">
      <h5>01829-077648</h5>
    </div>

    <div class="col-lg-2 col-sm-12 col-md-12 text-center">
     <h5> <a href="" style="color:#fff;">umsdtl@gmail.com</a></h5>
    </div>

    <div class="col-lg-4 col-sm-12 col-md-12 ">
        <div class="social-media text-center ">
          <a href=""><i class="fab facebook fa-facebook-f"></i></a>
          <a href=""><i class="fab twitter fa-twitter"></i></a>
          <a href=""><i class="fab instagram fa-instagram"></i> </a>
          <a href=""><i class="fab linkedin fa-linkedin-in"></i> </a>
          <a href=""><i class="fab pinterest fa-pinterest-p"></i></a>
        </div>
    </div>
  
  </div>

</div>

      

<! End of Header  !>

      <div class="title-area">

      <div class="row p-5">

      <div class="col-lg-2 col-sm-12 col-md-12 text-center">
          <div class="logo-area text-sm-center">
            <img src="../images/logo.jpg" alt="" style="height:60px ;">
			    </div>
		    </div>

        <div class="col-lg-10">
        <h3 class=" ">UNITED MULTIMEDIA SKILL DEVELOPMENT TECHNOLOGY LTD</h3>
        </div>

      </div>

      </div>


<! Menu  !>



  <div class="menu-area " style="">

       <div class="container">


      <div class="col ">
          <div class="menu text-center">

          <ul class="list-unstyled list-inline ">
            <li class="list-inline-item "><a class="nav-link menu-link" href="../index.php">Home</a></li>
            <li class="list-inline-item"><a class="nav-link menu-link " href="../about_page.php">About-Us</a></li>

            <li class="list-inline-item"><div class="dropdown show">
            <a class="nav-link menu-link dropdown-toggle" href="" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Courses</a> 
            <div class="dropdown-menu course-menu" aria-labelledby="dropdownMenuLink">
              <a class="dropdown-item course-item" href="affliateMarketing.php">Affliate Marketing</a>
              <a class="dropdown-item course-item" href="autocad.php">Autocad</a>
              <a class="dropdown-item course-item" href="basicCom.php">Computer Office Application</a>
              <a class="dropdown-item course-item" href="cpaDesign.php">CPA Marketing</a>
              <a class="dropdown-item course-item" href="digitalMarketing.php">Digital Marketing</a>
              <a class="dropdown-item course-item" href="driving.php">Driving</a>
              <a class="dropdown-item course-item" href="facebookMarketing.php">Facebook Marketing</a>
              <a class="dropdown-item course-item" href="graphicDesign.php">Graphic Design</a>
            
            <a class="dropdown-item course-item" href="hardware.php">Computer Hardware</a>
          
            <a class="dropdown-item course-item" href="spokenEng.php">Spoken English</a>
            <a class="dropdown-item course-item" href="webDesign.php">Web Design & Development</a>
            <a class="dropdown-item course-item" href="youtubeMarketing.php">Youtube Marketing</a>  </div>
          </li>

            <li class="list-inline-item"><a class="nav-link menu-link" href="../contact_page.php" >Contact-Us</a></li> 
            <li class="list-inline-item"><a class="nav-link menu-link " href="../registration_page.php">Registration</a></li> 
        </ul>

          </div>
      </div>

      

    </div>

    </div>




<! End of Menu !>

