<?php include 'link.php'; ?>


<! Header  !>

<div class="header-area" >

  <div class="row">

 
<div class="col-lg-1">

</div>

  <div class="col-lg-2 col-sm-12 col-md-12 text-center">
        <div class="row">
          <div class="col-lg-2">
              <h5> <i class="fas fa-phone " style="transform:rotate(100deg);"></i></h5>
          </div>
              <div class="col-lg-10">
                 <h5 class="text-left">01829-077648</h5>
              </div>
        </div>
    </div>

   
    <div class="col-lg-2 col-sm-12 col-md-12 text-center">
        <div class="row">
          <div class="col-lg-2">
              <h5> <i class="fas fa-phone " style="transform:rotate(100deg);"></i></h5>
          </div>
              <div class="col-lg-10">
                 <h5 class="text-left">01829-077648</h5>
              </div>
        </div>
    </div>



    <div class="col-lg-2 col-sm-12 col-md-12 text-center">
     <h5> <a href="" style="color:#fff;">umsdtl2019@gmail.com</a></h5>
    </div>

   

    <div class="col-lg-2 col-sm-12 col-md-12 ">
        <div class="social-media text-center ">
          <a href="https://www.facebook.com/United-multimedia-skill-development-technology-limited-103877671204563/"><i class="fab facebook fa-facebook-f"></i></a>
          <a href="https://twitter.com/umsdtl "><i class="fab twitter fa-twitter"></i></a>
          <a href="https://www.linkedin.com/in/ums-dtl-6945841a2/"><i class="fab linkedin fa-linkedin-in"></i> </a>
       
        </div>
    </div>


     
    <div class="col-lg-2 col-sm-12 col-md-12 ">
        <div class="registration">
        <a href="registration_page.php" class="regi-btn">Registration</a>
        </div>
        </div>
  
  </div>

</div>

      

<! End of Header  !>

      <div class="title-area">

      <div class="row p-5">

     

        <div class="col">
        <h3 class="text-center">UNITED MULTIMEDIA SKILL DEVELOPMENT TECHNOLOGY LTD</h3>
        </div>

      </div>

      </div>


<! Menu  !>



  <div class="menu-area " style="">

       <div class="container">


      <div class="col ">
          <div class="menu text-center">

          <ul class="list-unstyled list-inline ">
            <li class="list-inline-item "><a class="nav-link menu-link" href="index.php">Home</a></li>
            <li class="list-inline-item"><a class="nav-link menu-link " href="about_page.php">About-Us</a></li>

            <li class="list-inline-item"><div class="dropdown show">
            <a class="nav-link menu-link dropdown-toggle" href="" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #333333;">Courses</a> 
            <div class="dropdown-menu course-menu" aria-labelledby="dropdownMenuLink">
              <a class="dropdown-item course-item" href="courses/affliateMarketing.php">Affliate Marketing</a>
              <a class="dropdown-item course-item" href="courses/autocad.php">Autocad</a>
              <a class="dropdown-item course-item" href="courses/basicCom.php">Computer Office Application</a>
              <a class="dropdown-item course-item" href="courses/cpaDesign.php">CPA Marketing</a>
              <a class="dropdown-item course-item" href="courses/digitalMarketing.php">Digital Marketing</a>
              <a class="dropdown-item course-item" href="courses/driving.php">Driving</a>
              <a class="dropdown-item course-item" href="courses/facebookMarketing.php">Facebook Marketing</a>
              <a class="dropdown-item course-item" href="courses/graphicDesign.php">Graphic Design</a>
            
            <a class="dropdown-item course-item" href="courses/hardware.php">Computer Hardware</a>
          
            <a class="dropdown-item course-item" href="courses/spokenEng.php">Spoken English</a>
            <a class="dropdown-item course-item" href="courses/webDesign.php">Web Design & Development</a>
            <a class="dropdown-item course-item" href="courses/youtubeMarketing.php">Youtube Marketing</a>  </div>
          </li>
          <li class="list-inline-item"><a class="nav-link menu-link" href="gallery_page.php" >Gallery</a></li> 
            <li class="list-inline-item"><a class="nav-link menu-link" href="contact_page.php" >Contact-Us</a></li> 
            
        </ul>

          </div>
      </div>

      

    </div>

    </div>




<! End of Menu !>

